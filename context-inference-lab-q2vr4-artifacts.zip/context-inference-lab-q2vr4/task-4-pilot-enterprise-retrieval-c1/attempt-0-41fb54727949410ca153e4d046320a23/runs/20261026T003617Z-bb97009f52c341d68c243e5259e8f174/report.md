# Context reduction experiment

Run `20261026T003617Z-bb97009f52c341d68c243e5259e8f174` for experiment `pilot-enterprise`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| retrieval | 1 | 810.800 | n/a | 0.200 | 0.600 | 0.334/0.343 | 6.774/9.072 | 16.897 | 0.148 | 0.014 | 20510.000 | 67.764 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
