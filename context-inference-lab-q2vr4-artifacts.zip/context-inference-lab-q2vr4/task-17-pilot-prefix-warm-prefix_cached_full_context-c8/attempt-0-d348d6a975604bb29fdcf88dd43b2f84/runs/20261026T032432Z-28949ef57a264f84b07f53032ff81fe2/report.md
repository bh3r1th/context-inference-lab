# Context reduction experiment

Run `20261026T032432Z-28949ef57a264f84b07f53032ff81fe2` for experiment `pilot-prefix-warm`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| prefix_cached_full_context | 8 | 27701.900 | n/a | 0.200 | 0.500 | 0.699/1.251 | 8.458/11.171 | 59.941 | 0.659 | 0.414 | 20510.000 | 15.165 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
