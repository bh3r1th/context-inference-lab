# Context reduction experiment

Run `20261026T031316Z-37415a8faf4e469aaf2c0f33bba9ac3a` for experiment `pilot-prefix-warm`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| prefix_cached_full_context | 1 | 27701.900 | n/a | 0.200 | 0.500 | 0.228/0.245 | 6.400/6.943 | 15.244 | 0.160 | 0.400 | 20510.000 | 62.581 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
