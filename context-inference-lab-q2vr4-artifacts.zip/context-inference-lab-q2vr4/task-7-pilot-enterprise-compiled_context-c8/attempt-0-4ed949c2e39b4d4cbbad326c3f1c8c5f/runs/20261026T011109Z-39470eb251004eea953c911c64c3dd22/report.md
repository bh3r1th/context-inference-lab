# Context reduction experiment

Run `20261026T011109Z-39470eb251004eea953c911c64c3dd22` for experiment `pilot-enterprise`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| compiled_context | 8 | 555.100 | n/a | 0.200 | 0.400 | 0.746/1.251 | 7.212/9.062 | 79.399 | 0.788 | 0.066 | 20510.000 | 12.695 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
