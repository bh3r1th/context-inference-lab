# Context reduction experiment

Run `20261026T025923Z-2dce3962be024ceb9d7c39ad209aca7f` for experiment `pilot-prefix-cold`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| prefix_cached_full_context | 8 | 27701.900 | n/a | 0.200 | 0.500 | 13.239/13.324 | 19.466/22.120 | 31.379 | 0.370 | 0.413 | 20510.000 | 27.056 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
