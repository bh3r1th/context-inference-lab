# Context reduction experiment

Run `20261026T002303Z-fe530ec0aa3d4c3187a2e60b82b69c6d` for experiment `pilot-enterprise`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| prefix_cached_full_context | 8 | 27701.900 | n/a | 0.100 | 0.500 | 0.775/1.227 | 8.659/10.562 | 58.502 | 0.635 | 0.414 | 20510.000 | 15.760 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
