# Context reduction experiment

Run `20261026T004855Z-357dc6a2fdfa4644af59c2f950905104` for experiment `pilot-enterprise`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| retrieval | 8 | 810.800 | n/a | 0.200 | 0.600 | 1.102/1.985 | 9.080/10.563 | 75.929 | 0.700 | 0.102 | 20510.000 | 14.290 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
