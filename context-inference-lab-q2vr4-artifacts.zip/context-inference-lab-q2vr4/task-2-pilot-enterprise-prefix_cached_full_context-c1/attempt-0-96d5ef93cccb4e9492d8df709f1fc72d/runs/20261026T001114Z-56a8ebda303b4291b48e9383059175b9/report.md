# Context reduction experiment

Run `20261026T001114Z-56a8ebda303b4291b48e9383059175b9` for experiment `pilot-enterprise`.

This report compares measured inference performance and decision quality. It makes no claims for metrics recorded as `n/a`.

| Strategy | Concurrency | Context tokens | Reduction % | Correctness | Critical miss rate | TTFT p50/p95 (s) | Latency p50/p95 (s) | Output tok/s | Requests/s | KV p95 | GPU MiB p95 | Batch s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| prefix_cached_full_context | 1 | 27701.900 | n/a | 0.200 | 0.500 | 0.226/0.238 | 6.382/6.930 | 15.295 | 0.160 | 0.400 | 20510.000 | 62.372 |

## Metric scope

- Context reduction uses the measured full-context token average at the same concurrency.
- TTFT and latency percentiles use successful measured requests only.
- KV-cache values are server telemetry; GPU memory values are local `nvidia-smi` telemetry.
- Missing telemetry or incomplete server usage is reported as `n/a`; it is not estimated.
