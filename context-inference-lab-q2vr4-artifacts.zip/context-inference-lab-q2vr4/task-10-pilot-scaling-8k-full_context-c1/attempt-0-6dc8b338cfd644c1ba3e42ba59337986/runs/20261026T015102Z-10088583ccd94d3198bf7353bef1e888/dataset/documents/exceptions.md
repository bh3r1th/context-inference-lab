# Fictional Meridian Services — exceptions.md

RULE {"document": "exceptions.md", "fact": "An emergency with an incident_id replaces the city and department limits with 1000 USD. Cite R_EMERGENCY, R_BASE, the city row, and R_DEPARTMENT if FIELD. Vendor controls still apply.", "id": "R_EMERGENCY", "section": "Appendix Q. Incident travel", "when": {"emergency": true}}
