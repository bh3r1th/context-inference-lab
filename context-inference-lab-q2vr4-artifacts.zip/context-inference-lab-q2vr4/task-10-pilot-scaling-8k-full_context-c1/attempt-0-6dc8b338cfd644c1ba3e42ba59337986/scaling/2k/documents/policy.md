# Fictional Meridian Services — policy.md

RULE {"document": "policy.md", "fact": "Travel expenses in USD are approved when amount_usd is at or below the applicable limit, otherwise rejected. All amounts are whole dollars. Cite R_BASE and the city row.", "id": "R_BASE", "section": "1. Expense eligibility", "when": {}}

RULE {"document": "policy.md", "fact": "Before applying any other rule, abstain with null limit and cite only R_ABSTAIN if city has no lookup row, category is not travel, currency is not USD, amount_usd is missing or is not a nonnegative integer, department is not OFFICE or FIELD, vendor_status is not clear or restricted, emergency is missing or not boolean, emergency is true without incident_id, or receipt_amount_usd is present and differs from amount_usd. Missing city, category, currency, department, or vendor_status also requires abstention.", "id": "R_ABSTAIN", "section": "0. Evidence completeness", "when": {}}

RULE {"document": "policy.md", "fact": "FIELD travel uses the lower of the city limit and 150 USD. Cite R_DEPARTMENT as well.", "id": "R_DEPARTMENT", "section": "9. Department budgets", "when": {"department": "FIELD"}}
