# Fictional Meridian Services — controls.md

RULE {"document": "controls.md", "fact": "A restricted vendor must be rejected even during an emergency. Retain the applicable limit and cite R_VENDOR and all rules used to establish that limit.", "id": "R_VENDOR", "section": "3. Vendor screening", "when": {"vendor_status": "restricted"}}
