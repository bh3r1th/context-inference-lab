# Fictional Meridian Services — lookup.md

RULE {"document": "lookup.md", "fact": "Harbor-0000 travel limit is 200 USD.", "id": "L_CITY_0000", "section": "Harbor-0000", "when": {"city": "Harbor-0000"}}

RULE {"document": "lookup.md", "fact": "Harbor-0001 travel limit is 350 USD.", "id": "L_CITY_0001", "section": "Harbor-0001", "when": {"city": "Harbor-0001"}}

RULE {"document": "lookup.md", "fact": "Harbor-0002 travel limit is 400 USD.", "id": "L_CITY_0002", "section": "Harbor-0002", "when": {"city": "Harbor-0002"}}

RULE {"document": "lookup.md", "fact": "Harbor-0003 travel limit is 350 USD.", "id": "L_CITY_0003", "section": "Harbor-0003", "when": {"city": "Harbor-0003"}}

RULE {"document": "lookup.md", "fact": "Harbor-0004 travel limit is 250 USD.", "id": "L_CITY_0004", "section": "Harbor-0004", "when": {"city": "Harbor-0004"}}

RULE {"document": "lookup.md", "fact": "Harbor-0005 travel limit is 200 USD.", "id": "L_CITY_0005", "section": "Harbor-0005", "when": {"city": "Harbor-0005"}}

RULE {"document": "lookup.md", "fact": "Harbor-0006 travel limit is 250 USD.", "id": "L_CITY_0006", "section": "Harbor-0006", "when": {"city": "Harbor-0006"}}

RULE {"document": "lookup.md", "fact": "Harbor-0007 travel limit is 300 USD.", "id": "L_CITY_0007", "section": "Harbor-0007", "when": {"city": "Harbor-0007"}}

RULE {"document": "lookup.md", "fact": "Harbor-0008 travel limit is 400 USD.", "id": "L_CITY_0008", "section": "Harbor-0008", "when": {"city": "Harbor-0008"}}

RULE {"document": "lookup.md", "fact": "Harbor-0009 travel limit is 300 USD.", "id": "L_CITY_0009", "section": "Harbor-0009", "when": {"city": "Harbor-0009"}}

RULE {"document": "lookup.md", "fact": "Harbor-0010 travel limit is 300 USD.", "id": "L_CITY_0010", "section": "Harbor-0010", "when": {"city": "Harbor-0010"}}

RULE {"document": "lookup.md", "fact": "Harbor-0011 travel limit is 250 USD.", "id": "L_CITY_0011", "section": "Harbor-0011", "when": {"city": "Harbor-0011"}}

RULE {"document": "lookup.md", "fact": "Harbor-0012 travel limit is 250 USD.", "id": "L_CITY_0012", "section": "Harbor-0012", "when": {"city": "Harbor-0012"}}

RULE {"document": "lookup.md", "fact": "Harbor-0013 travel limit is 400 USD.", "id": "L_CITY_0013", "section": "Harbor-0013", "when": {"city": "Harbor-0013"}}

RULE {"document": "lookup.md", "fact": "Harbor-0014 travel limit is 350 USD.", "id": "L_CITY_0014", "section": "Harbor-0014", "when": {"city": "Harbor-0014"}}

RULE {"document": "lookup.md", "fact": "Harbor-0015 travel limit is 200 USD.", "id": "L_CITY_0015", "section": "Harbor-0015", "when": {"city": "Harbor-0015"}}

RULE {"document": "lookup.md", "fact": "Harbor-0016 travel limit is 400 USD.", "id": "L_CITY_0016", "section": "Harbor-0016", "when": {"city": "Harbor-0016"}}

RULE {"document": "lookup.md", "fact": "Harbor-0017 travel limit is 350 USD.", "id": "L_CITY_0017", "section": "Harbor-0017", "when": {"city": "Harbor-0017"}}

RULE {"document": "lookup.md", "fact": "Harbor-0018 travel limit is 300 USD.", "id": "L_CITY_0018", "section": "Harbor-0018", "when": {"city": "Harbor-0018"}}

RULE {"document": "lookup.md", "fact": "Harbor-0019 travel limit is 350 USD.", "id": "L_CITY_0019", "section": "Harbor-0019", "when": {"city": "Harbor-0019"}}

RULE {"document": "lookup.md", "fact": "Harbor-0020 travel limit is 300 USD.", "id": "L_CITY_0020", "section": "Harbor-0020", "when": {"city": "Harbor-0020"}}

RULE {"document": "lookup.md", "fact": "Harbor-0021 travel limit is 350 USD.", "id": "L_CITY_0021", "section": "Harbor-0021", "when": {"city": "Harbor-0021"}}

RULE {"document": "lookup.md", "fact": "Harbor-0022 travel limit is 400 USD.", "id": "L_CITY_0022", "section": "Harbor-0022", "when": {"city": "Harbor-0022"}}

RULE {"document": "lookup.md", "fact": "Harbor-0023 travel limit is 300 USD.", "id": "L_CITY_0023", "section": "Harbor-0023", "when": {"city": "Harbor-0023"}}
